"""
scripts/generate_pdf_report.py
==============================
Builds the formal academic PDF research report for the Apart Research
AI Collusion Research Sprint 2026 submission using ReportLab Platypus.

Ensures strict compliance with official template and event guidelines:
- Title: When Correlation Lies: Stress-Testing Pairwise Net Influence for Detecting Coordination Among Agents
- Track 1.4: Markets and Collusion
- Author: Durgesh Unde, Affiliation: Independent Researcher
- Event: Apart Research AI Collusion Research Sprint (October 23–25, 2026)
- Abstract: exactly within 150-250 words
- Hard cap: 8 pages; Target: 6-7 pages
- Clean page breaks: zero split tables or orphaned headers
- No "Confidential" header/footer
- Accurate citations (Agrawal et al., 2025 arXiv:2507.01413; Bonjour et al., 2022)
- Required Appendices: Limitations and Dual-Use / Ethical Considerations, LLM Usage Statement
- Embedded PDF document metadata: Author, Title, Subject
"""

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak
)
from reportlab.pdfgen import canvas

REPORT_DIR = PROJECT_ROOT / "report"
FIGURES_DIR = PROJECT_ROOT / "results" / "figures"
PDF_PATH = REPORT_DIR / "when_correlation_lies_report.pdf"


class NumberedCanvas(canvas.Canvas):
    """Two-pass canvas to dynamically compute and print 'Page X of Y' and set PDF metadata."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_decorations(num_pages)
            super().showPage()
        
        # Embed proper document metadata
        self.setAuthor("Durgesh Unde")
        self.setTitle("When Correlation Lies: Stress-Testing Pairwise Net Influence for Detecting Coordination Among Agents")
        self.setSubject("Apart Research AI Collusion Research Sprint 2026 - Track 1.4: Markets and Collusion")
        self.setCreator("ReportLab Platypus / Python 3.13")
        super().save()

    def draw_page_decorations(self, total_pages):
        self.saveState()
        self.setFont("Helvetica", 8)
        self.setFillColor(colors.HexColor("#555555"))
        
        # Running Header (Pages 2+)
        if self._pageNumber > 1:
            self.drawString(50, 11 * inch - 36, "When Correlation Lies: Stress-Testing Pairwise Net Influence")
            self.drawRightString(8.5 * inch - 50, 11 * inch - 36, "Apart Research Sprint 2026 — Track 1.4")
            self.setStrokeColor(colors.HexColor("#CCCCCC"))
            self.setLineWidth(0.5)
            self.line(50, 11 * inch - 40, 8.5 * inch - 50, 11 * inch - 40)
        
        # Running Footer
        footer_text = f"Page {self._pageNumber} of {total_pages}"
        self.drawRightString(8.5 * inch - 50, 30, footer_text)
        self.drawString(50, 30, "Apart Research AI Collusion Research Sprint 2026 — Track 1.4: Markets and Collusion")
        self.setStrokeColor(colors.HexColor("#CCCCCC"))
        self.setLineWidth(0.5)
        self.line(50, 40, 8.5 * inch - 50, 40)
        self.restoreState()


def build_pdf():
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    doc = SimpleDocTemplate(
        str(PDF_PATH),
        pagesize=letter,
        leftMargin=50,
        rightMargin=50,
        topMargin=44,
        bottomMargin=44,
    )
    doc.author = "Durgesh Unde"
    doc.title = "When Correlation Lies: Stress-Testing Pairwise Net Influence for Detecting Coordination Among Agents"
    doc.subject = "Apart Research AI Collusion Research Sprint 2026 - Track 1.4: Markets and Collusion"

    styles = getSampleStyleSheet()

    title_style = ParagraphStyle(
        "DocTitle",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=14.0,
        leading=17.5,
        textColor=colors.HexColor("#0D47A1"),
        alignment=1,
        spaceAfter=3,
    )

    track_style = ParagraphStyle(
        "DocTrack",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=8.8,
        leading=11.5,
        textColor=colors.HexColor("#1976D2"),
        alignment=1,
        spaceAfter=3,
    )

    author_style = ParagraphStyle(
        "DocAuthors",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=8.0,
        leading=11.0,
        textColor=colors.HexColor("#263238"),
        alignment=1,
        spaceAfter=5,
    )

    abstract_heading = ParagraphStyle(
        "AbstractHead",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=8.2,
        leading=10.0,
        textColor=colors.HexColor("#0D47A1"),
        spaceAfter=2,
    )

    abstract_body = ParagraphStyle(
        "AbstractBody",
        parent=styles["Normal"],
        fontName="Helvetica-Oblique",
        fontSize=7.2,
        leading=9.5,
        textColor=colors.HexColor("#263238"),
    )

    h1_style = ParagraphStyle(
        "Heading1_Custom",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=9.2,
        leading=11.5,
        textColor=colors.HexColor("#0D47A1"),
        spaceBefore=4,
        spaceAfter=1.5,
        keepWithNext=True,
    )

    h2_style = ParagraphStyle(
        "Heading2_Custom",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=8.0,
        leading=10.2,
        textColor=colors.HexColor("#1976D2"),
        spaceBefore=3,
        spaceAfter=1.2,
        keepWithNext=True,
    )

    body_style = ParagraphStyle(
        "Body_Custom",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=7.2,
        leading=9.2,
        textColor=colors.HexColor("#212121"),
        spaceAfter=1.8,
    )

    bullet_style = ParagraphStyle(
        "Bullet_Custom",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=7.2,
        leading=9.2,
        textColor=colors.HexColor("#212121"),
        leftIndent=8,
        spaceAfter=1.0,
    )

    table_cell = ParagraphStyle(
        "TableCell",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=5.6,
        leading=7.0,
        alignment=1,
    )

    table_header = ParagraphStyle(
        "TableHeader",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=5.6,
        leading=7.0,
        textColor=colors.white,
        alignment=1,
    )

    caption_style = ParagraphStyle(
        "CaptionStyle",
        parent=styles["Normal"],
        fontName="Helvetica-Oblique",
        fontSize=6.3,
        leading=7.8,
        textColor=colors.HexColor("#555555"),
        alignment=1,
        spaceAfter=2.0,
    )

    story = []

    # =========================================================================
    # PAGE 1: Title, Author, Abstract, Section 1 (Intro & Hypotheses), Figure 0
    # =========================================================================
    story.append(Paragraph("When Correlation Lies: Stress-Testing Pairwise Net Influence for Detecting Coordination Among Agents<sup>1</sup>", title_style))
    story.append(Paragraph("Track 1.4: Markets and Collusion &nbsp;|&nbsp; Apart Research AI Collusion Research Sprint (October 23–25, 2026)", track_style))
    story.append(Paragraph("<b>Author:</b> Durgesh Unde &nbsp;|&nbsp; <b>Affiliation:</b> Independent Researcher<br/><b>Verified Pipeline:</b> Python 3.13 / CPU Benchmarks & Modal CPU Cloud ($40.63 Metered Cost, $40.12 Promotional Credit, $0.00 Out-of-Pocket Spend)<br/><b>Evaluations:</b> Canonical Scripted: 260 trajectories (54,000 rounds across 300 evals) &nbsp;|&nbsp; Open-Weight LLM: 630 trajectories (68,400 decisions)", author_style))

    abstract_text = (
        "As autonomous AI agents are increasingly deployed in high-frequency trading, automated procurement, and algorithmic pricing, "
        "covert collusion poses severe economic and systemic risks. Information-theoretic detectors, notably Pairwise Net Influence (PNI; Bonjour et al., 2022), "
        "measure directed action dependence via Conditional Mutual Information (CMI) conditioned on observable public game state. "
        "However, whether PNI can distinguish deliberate multi-agent coordination from spurious correlation induced by shared context remains an open empirical question. "
        "In this work, we stress-test PNI against unconditioned marginal mutual information and raw conditional mutual information baselines in an iterated 4-agent game across four controlled conditions: "
        "independent play, shared-context confounding, shared-private-signal coordination, and coordination-strength sweeps. "
        "Across 20 independent seeds and trajectory lengths (T in [50, 500]), unconditioned mutual information exhibits a 38-fold surge under shared context, "
        "falsely accusing independent agents of collusion (FPR = 1.000). Conditioning on observable state neutralizes this contextual surge below independent calibration thresholds (CMI FPR = 0.000), "
        "while PNI competitor subtraction isolates coordinating pairs with 100% Top-1 ranking accuracy (Wilson 95% CI: [0.839, 1.000], MRR = 1.000). "
        "Furthermore, expanding evaluations to 68,400 open-weight LLM decisions (Qwen2.5-1.5B, 630 trajectories) across horizons T in {5, 20, 50} reveals an empirical finite-sample sparsity effect: "
        "ultra-short horizons (T=5) attenuate CMI ranking accuracy (70.0%), whereas sufficient history (T >= 20) restores 100% Top-1 identification accuracy under controlled ranking evidence. "
        "Our findings support state conditioning as a useful safeguard in the tested setting while highlighting critical sample horizon boundaries."
    )
    abstract_content = [
        [Paragraph("<b>ABSTRACT</b>", abstract_heading)],
        [Paragraph(abstract_text, abstract_body)]
    ]
    t_abstract = Table(abstract_content, colWidths=[7.1 * inch])
    t_abstract.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor("#F0F4F8")),
        ('BOX', (0, 0), (-1, -1), 0.75, colors.HexColor("#B0BEC5")),
        ('PADDING', (0, 0), (-1, -1), 3.5),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 1),
    ]))
    story.append(t_abstract)
    story.append(Spacer(1, 2))

    story.append(Paragraph("1. Introduction", h1_style))
    story.append(Paragraph(
        "Autonomous algorithmic agents increasingly govern financial exchanges, automated multi-unit auctions, and dynamic e-commerce pricing. "
        "A critical frontier in AI safety is preventing <b>algorithmic collusion</b>—scenarios where autonomous agents synchronize strategies to extract "
        "supracompetitive rents at the expense of human market participants (Calvano et al., 2020; Schwalbe, 2018). Unlike traditional cartels that rely on "
        "explicit communication logs, AI agents can establish implicit coordination purely through tacit observational learning or private coordination signals. "
        "Consequently, behavioral auditing tools that operate solely on external observational logs are essential for oversight.",
        body_style
    ))
    story.append(Paragraph(
        "In Track 1.4 (Markets and Collusion) of the AI Collusion Research Sprint, we address the core research question: "
        "<i>Can information-theoretic approaches detect collusion in multi-agent games?</i> "
        "Specifically, we stress-test <b>Pairwise Net Influence (PNI)</b> (Bonjour, Aggarwal, & Bhargava, UAI 2022). While PNI is theoretically sound, "
        "real-world market auditing confronts a severe confounder: <b>shared-context confounding</b>. When non-coordinating agents independently "
        "react to identical market histories, price shocks, or public order books, their actions naturally synchronize. "
        "If auditing metrics mistake this context-driven synchronization for collusion, benign market makers will face false enforcement sanctions.",
        body_style
    ))
    story.append(Paragraph(
        "<b>Core Research Question:</b> <i>How reliably does Pairwise Net Influence distinguish deliberately coordinated behavior from "
        "independent behavior that merely appears correlated due to shared context, and how does detector performance scale with coordination "
        "strength, trajectory length, and open-weight LLM architectures?</i>",
        body_style
    ))
    story.append(Paragraph(
        "To rigorously separate the effects of state conditioning from rival competitor subtraction, we formulate and evaluate four hypotheses "
        "across three distinct estimators—Marginal MI I(A_i; A_j), Conditional MI gamma(i, j) = I(A_i; A_j | S), and PNI net score—using a frozen "
        "canonical benchmark of 260 unique trajectories (54,000 recorded rounds across 300 evaluations) complemented by 68,400 open-weight LLM agent decisions across 630 trajectories:",
        body_style
    ))
    story.append(Paragraph("• <b>H1 (Positive Sensitivity):</b> Under controlled shared-private-signal coordination, PNI ranks the coordinating pair #1 significantly above the 1/6 (16.7%) random baseline.", bullet_style))
    story.append(Paragraph("• <b>H2 (Shared-Context Confounding):</b> Observable public state induces severe spurious action correlation, causing unconditioned marginal mutual information to suffer a 100% false positive rate.", bullet_style))
    story.append(Paragraph("• <b>H3 (State-Conditioning Neutralization & Rival Subtraction):</b> Conditioning on observable state S neutralizes this broadcast shock below independent calibration thresholds, while PNI rival subtraction further isolates pair-specific influence.", bullet_style))
    story.append(Paragraph("• <b>H4 (Sensitivity Scaling):</b> PNI identification scores degrade predictably and monotonically as joint coordination probability alpha decreases towards independent play.", bullet_style))
    story.append(Spacer(1, 2))

    fig0_path = FIGURES_DIR / "fig0_experimental_setup.png"
    if fig0_path.exists():
        story.append(Image(str(fig0_path), width=7.0 * inch, height=1.70 * inch))
        story.append(Paragraph("<b>Figure 1: Experimental Architecture and Game Pipeline.</b> 4-agent iterated simultaneous tournament with observable state transitions S_t = a^{t-1}, controlled confounding mechanisms, and information-theoretic auditing estimators.", caption_style))

    # =========================================================================
    # PAGE 2: Related Work, Methods
    # =========================================================================
    story.append(PageBreak())

    story.append(Paragraph("2. Related Work", h1_style))
    story.append(Paragraph(
        "<b>2.1 Information-Theoretic Multi-Agent Influence:</b> Information theory offers a non-parametric foundation for quantifying multi-agent dependence "
        "without restrictive linear or parametric assumptions (Cover & Thomas, 2006). Bonjour, Aggarwal, and Bhargava (UAI 2022) formulated individual "
        "influence in simultaneous games using Conditional Mutual Information (CMI) conditioned on observable game state: "
        "gamma(i, j) = I(A_i; A_j | S) = H(A_j | S) - H(A_j | A_i, S). In simultaneous games, raw CMI is symmetric. To isolate pair-specific coordination "
        "from symmetric broadcast shocks, Bonjour et al. introduced <i>directed net influence</i> by subtracting the strongest competing rival influence: "
        "Gamma(i -&gt; j) = gamma(i, j) - max_{k != i, j} gamma(k, j). A candidate pair is assigned the score Score_PNI(i, j) = min(Gamma(i -&gt; j), Gamma(j -&gt; i)). "
        "While Bonjour et al. established theoretical bounds in matrix games, they did not evaluate empirical false-positive inflation under shared-context confounding, "
        "separate raw CMI from rival subtraction, or calibrate decision thresholds on negative controls.",
        body_style
    ))
    story.append(Paragraph(
        "<b>2.2 Algorithmic and LLM Collusion in Economics:</b> Extensive literature demonstrates that Q-learning and reinforcement learning agents can autonomously "
        "sustain collusive pricing above competitive Nash equilibria without explicit communication (Calvano et al., 2020; Schwalbe, 2018). Recently, Agrawal et al. (2025; "
        "arXiv:2507.01413) extended collusion auditing to LLM agents participating in double auctions, establishing that language model agents can form tacit cartels "
        "through contextual prompting. However, current LLM collusion studies evaluate aggregate market distortion (e.g., supracompetitive bid-ask spreads) rather than "
        "information-theoretic ranking detectors capable of identifying the specific colluding coalition.",
        body_style
    ))
    story.append(Paragraph(
        "<b>2.3 Finite-Sample Entropy Estimation & Regularization:</b> Discrete plug-in estimators of entropy and mutual information natively evaluate unvisited cells "
        "via the standard mathematical convention 0 log 0 = 0. Smoothing (e.g., Bayesian Dirichlet smoothing with Jeffreys pseudocounts lambda = 0.5; Holste et al., 1998) "
        "is therefore not mathematically required to prevent division by zero. Rather, smoothing serves as a regularized estimation choice that stabilizes probability mass "
        "across sparsely sampled state-action cells in finite sample regimes (Paninski, 2003). We explicitly evaluate the sensitivity of our empirical findings across smoothing parameter lambda in {0.0, 0.5, 1.0}.",
        body_style
    ))
    story.append(Spacer(1, 2))

    story.append(Paragraph("3. Methods", h1_style))
    story.append(Paragraph(
        "<b>3.1 Iterated Multi-Agent Game Environment:</b> Following Bonjour et al. (2022) and sprint starter guidelines, we implement a 4-player iterated Rock-Paper-Scissors (RPS) tournament. "
        "The action space is A = {Rock: 0, Paper: 1, Scissors: 2}. In round t, each agent i executes simultaneous action a_i^t. The round payoff is the tournament sum of pairwise zero-sum payoffs: "
        "pi_i(a^t) = sum_{j != i} U(a_i^t, a_j^t), where U in {-1, 0, 1}. The public observable state S_t is the joint action profile of round t-1: "
        "S_t = (a_0^{t-1}, a_1^{t-1}, a_2^{t-1}, a_3^{t-1}) in A^4, yielding |S| = 3^4 + 1 = 82 observable states (including initial START state).",
        body_style
    ))
    story.append(Paragraph(
        "<b>3.2 Controlled Experimental Conditions:</b> To isolate causal confounding mechanisms, we evaluate four strictly partitioned conditions:<br/>"
        "• <b>Condition A (Independent Negative Control):</b> 4 uniform-random agents with isolated RNGs. Zero coordination or state dependence. Seeds 0–4 are reserved strictly for threshold calibration; seeds 5–19 (n=15) are strictly held-out test evaluations.<br/>"
        "• <b>Condition B (Shared-Context Confounding Negative Control):</b> Agents independently execute a best response to the dominant action in S_t with 10% independent noise. Agents are conditionally independent given S_t, but unconditionally correlated due to the shared state (n=20).<br/>"
        "• <b>Condition C (Shared-Private-Signal Coordination Positive Control):</b> Agents 0 and 1 receive a private common signal Z_t ~ Uniform({0, 1, 2}), executing identical coordinated actions. Agents 2 and 3 play independent best responses. This establishes a controlled statistical signature of conditional action dependence in scripted RPS, though it does not by itself prove a real-world economic cartel (n=20).<br/>"
        "• <b>Condition D (Coordination Strength Sweep):</b> In each round, a joint coordination gate G_t ~ Bernoulli(alpha) is drawn. If G_t = 1, both agents 0 and 1 follow private signal Z_t; if G_t = 0, neither receives Z_t and both independently execute fallback best response. This guarantees the pair coordinates with probability alpha (n=20 per alpha in {0.25, 0.50, 0.75, 1.00}).",
        body_style
    ))
    story.append(Paragraph(
        "<b>3.3 Triangulated Estimators & Calibrated Decision Thresholds:</b> To disentangle conditioning from competitor subtraction, we evaluate three statistics: "
        "(1) <i>Marginal MI:</i> Score_MI(i, j) = I(A_i; A_j); (2) <i>Conditional MI:</i> Score_CMI(i, j) = gamma(i, j) = I(A_i; A_j | S); (3) <i>Pairwise Net Influence (PNI):</i> "
        "Score_PNI(i, j) = min(Gamma(i -&gt; j), Gamma(j -&gt; i)). Probabilities are estimated with Dirichlet smoothing (lambda = 0.5). "
        "Decision thresholds are calibrated via exploratory small-sample calibration on held-out validation trajectories (seeds 0–4 of Condition A, 30 candidate-pair scores) "
        "targeting nominal 5% FPR at the empirical 95th percentile (tau_MI = 0.030751 bits, tau_CMI = 0.117454 bits, tau_PNI = 0.010427 bits). "
        "Because 30 candidate-pair scores provide coarse quantile estimation, this serves as an empirical baseline rather than guaranteeing exact 5% population FPR. "
        "Condition A test FPR is evaluated strictly on held-out seeds 5–19 (n=15, 90 candidate pairs).",
        body_style
    ))
    story.append(Paragraph(
        "<b>3.4 Statistical Uncertainty Protocol & Degenerate Intervals:</b> All primary runs evaluate 20 independent pseudorandom seeds. "
        "For Top-1 accuracy (a bounded binomial proportion), we report exact <b>Wilson score confidence intervals</b> to prevent degenerate [1.0, 1.0] intervals. "
        "Continuous metrics (scores, FPR, MRR) report non-parametric bootstrap 95% confidence intervals over B = 2,000 resamples across independent trajectories. "
        "Whenever per-trajectory outcomes are completely identical across all 20 seeds (e.g., exactly 1 of 5 negative candidate pairs flagged in every seed), the resampled mean is constant, "
        "producing an interval of zero width (e.g., [0.200, 0.200]). We explicitly flag these degenerate intervals with asterisks and report the underlying empirical counts "
        "(flagged pairs / total negative pairs) to reflect that this represents uniform per-seed outcomes rather than zero population variance.",
        body_style
    ))

    # =========================================================================
    # PAGE 3: Primary Results (Table 1, Figure 2, Hypothesis Discoveries)
    # =========================================================================
    story.append(PageBreak())

    story.append(Paragraph("4. Results: Canonical Benchmark (T = 200 rounds)", h1_style))
    story.append(Paragraph(
        "We executed our complete frozen experimental protocol across all four conditions using T = 200 rounds and 20 independent pseudorandom seeds. "
        "Table 1 summarizes detection performance, comparing unconditioned Marginal MI against raw CMI and competitor-subtracted PNI net influence.",
        body_style
    ))

    headers1 = [
        "Condition", "GT Pair", "Marginal MI Top\n(95% CI)", "Marg. MI FPR\n[Counts]",
        "Cond. MI (CMI) Top\n(95% CI)", "CMI FPR\n[Counts]", "PNI Net Top\n(95% CI)",
        "PNI FPR\n[Counts]", "PNI Top-1\n(Wilson CI)", "PNI\nMRR"
    ]
    data1 = [
        [Paragraph(h, table_header) for h in headers1],
        [
            Paragraph("<b>Cond A (Test, n=15)</b>", table_cell), Paragraph("None", table_cell),
            Paragraph("0.025 [0.020, 0.031]", table_cell), Paragraph("0.033 [0.000, 0.067]<br/>(3/90)", table_cell),
            Paragraph("0.115 [0.111, 0.119]", table_cell), Paragraph("0.111 [0.044, 0.189]<br/>(10/90)", table_cell),
            Paragraph("0.005 [0.003, 0.008]", table_cell), Paragraph("0.022 [0.000, 0.056]<br/>(2/90)", table_cell),
            Paragraph("—", table_cell), Paragraph("—", table_cell)
        ],
        [
            Paragraph("<b>Cond A (Cal., n=5)</b>", table_cell), Paragraph("None", table_cell),
            Paragraph("0.027 [0.019, 0.036]", table_cell), Paragraph("0.067 [0.000, 0.133]<br/>(2/30)", table_cell),
            Paragraph("0.115 [0.111, 0.118]", table_cell), Paragraph("0.067 [0.000, 0.133]<br/>(2/30)", table_cell),
            Paragraph("0.007 [0.003, 0.012]", table_cell), Paragraph("0.067 [0.000, 0.133]<br/>(2/30)", table_cell),
            Paragraph("—", table_cell), Paragraph("—", table_cell)
        ],
        [
            Paragraph("<b>Cond B (Context, n=20)</b>", table_cell), Paragraph("None", table_cell),
            Paragraph("<b>0.958 [0.932, 0.984]</b>", table_cell), Paragraph("<b>1.000 [1.000, 1.000]*</b><br/>(120/120)", table_cell),
            Paragraph("<b>0.084 [0.081, 0.087]</b>", table_cell), Paragraph("<b>0.000 [0.000, 0.000]*</b><br/>(0/120)", table_cell),
            Paragraph("<b>0.012 [0.009, 0.015]</b>", table_cell), Paragraph("<b>0.100 [0.050, 0.158]</b><br/>(12/120)", table_cell),
            Paragraph("—", table_cell), Paragraph("—", table_cell)
        ],
        [
            Paragraph("<b>Cond C (Coord., n=20)</b>", table_cell), Paragraph("(0, 1)", table_cell),
            Paragraph("1.451 [1.447, 1.454]", table_cell), Paragraph("0.240 [0.200, 0.320]<br/>(24/100)", table_cell),
            Paragraph("0.797 [0.785, 0.808]", table_cell), Paragraph("0.020 [0.000, 0.050]<br/>(2/100)", table_cell),
            Paragraph("0.755 [0.741, 0.769]", table_cell), Paragraph("0.200 [0.200, 0.200]*<br/>(20/100)", table_cell),
            Paragraph("<b>1.000 [0.839, 1.000]</b>", table_cell), Paragraph("<b>1.000</b>", table_cell)
        ],
        [
            Paragraph("<b>Cond D (alpha=0.25)</b>", table_cell), Paragraph("(0, 1)", table_cell),
            Paragraph("1.024 [0.988, 1.062]", table_cell), Paragraph("1.000 [1.000, 1.000]*<br/>(100/100)", table_cell),
            Paragraph("0.329 [0.306, 0.353]", table_cell), Paragraph("0.010 [0.000, 0.030]<br/>(1/100)", table_cell),
            Paragraph("0.264 [0.239, 0.288]", table_cell), Paragraph("0.100 [0.060, 0.140]<br/>(10/100)", table_cell),
            Paragraph("<b>1.000 [0.839, 1.000]</b>", table_cell), Paragraph("<b>1.000</b>", table_cell)
        ],
        [
            Paragraph("<b>Cond D (alpha=0.50)</b>", table_cell), Paragraph("(0, 1)", table_cell),
            Paragraph("1.131 [1.090, 1.174]", table_cell), Paragraph("1.000 [1.000, 1.000]*<br/>(100/100)", table_cell),
            Paragraph("0.524 [0.497, 0.552]", table_cell), Paragraph("0.000 [0.000, 0.000]*<br/>(0/100)", table_cell),
            Paragraph("0.469 [0.442, 0.498]", table_cell), Paragraph("0.180 [0.150, 0.200]<br/>(18/100)", table_cell),
            Paragraph("<b>1.000 [0.839, 1.000]</b>", table_cell), Paragraph("<b>1.000</b>", table_cell)
        ],
        [
            Paragraph("<b>Cond D (alpha=0.75)</b>", table_cell), Paragraph("(0, 1)", table_cell),
            Paragraph("1.285 [1.259, 1.310]", table_cell), Paragraph("0.920 [0.830, 0.990]<br/>(92/100)", table_cell),
            Paragraph("0.669 [0.650, 0.686]", table_cell), Paragraph("0.020 [0.000, 0.050]<br/>(2/100)", table_cell),
            Paragraph("0.623 [0.600, 0.642]", table_cell), Paragraph("0.200 [0.200, 0.200]*<br/>(20/100)", table_cell),
            Paragraph("<b>1.000 [0.839, 1.000]</b>", table_cell), Paragraph("<b>1.000</b>", table_cell)
        ],
        [
            Paragraph("<b>Cond D (alpha=1.00)</b>", table_cell), Paragraph("(0, 1)", table_cell),
            Paragraph("1.452 [1.449, 1.455]", table_cell), Paragraph("0.240 [0.200, 0.300]<br/>(24/100)", table_cell),
            Paragraph("0.813 [0.802, 0.824]", table_cell), Paragraph("0.010 [0.000, 0.030]<br/>(1/100)", table_cell),
            Paragraph("0.771 [0.757, 0.784]", table_cell), Paragraph("0.200 [0.200, 0.200]*<br/>(20/100)", table_cell),
            Paragraph("<b>1.000 [0.839, 1.000]</b>", table_cell), Paragraph("<b>1.000</b>", table_cell)
        ],
    ]
    t1 = Table(data1, colWidths=[0.88*inch, 0.40*inch, 0.90*inch, 0.75*inch, 0.90*inch, 0.72*inch, 0.88*inch, 0.72*inch, 0.68*inch, 0.38*inch])
    t1.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#0D47A1")),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#CCCCCC")),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8F9FA")]),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('PADDING', (0, 0), (-1, -1), 1.0),
    ]))
    story.append(t1)
    story.append(Paragraph("<b>Table 1: Triangulated Benchmark Metrics (T = 200 rounds, 20 seeds).</b> Condition A test metrics computed on held-out seeds 5–19 (n=15). Brackets report 95% bootstrap CIs for continuous scores and exact Wilson CIs for Top-1 accuracy. Underlying counts report flagged pairs / total negative pairs. *Denotes degenerate bootstrap intervals resulting from uniform per-seed outcomes across all seeds rather than zero population variance.", caption_style))
    story.append(Spacer(1, 1))

    fig1_path = FIGURES_DIR / "fig1_top1_accuracy.png"
    fig2_path = FIGURES_DIR / "fig2_false_positive_rates.png"
    if fig1_path.exists() and fig2_path.exists():
        t_figs = Table([
            [Image(str(fig1_path), width=3.45 * inch, height=1.45 * inch),
             Image(str(fig2_path), width=3.45 * inch, height=1.45 * inch)]
        ], colWidths=[3.55 * inch, 3.55 * inch])
        t_figs.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('PADDING', (0, 0), (-1, -1), 0)]))
        story.append(t_figs)
        story.append(Paragraph("<b>Figure 2: Benchmark Performance Across Conditions.</b> Left: Top-1 Accuracy with exact Wilson 95% CIs. Right: False Positive Rates across negative controls and coordination sweeps.", caption_style))
    story.append(Spacer(1, 1))

    story.append(Paragraph("4.1 Evaluation of Hypotheses", h2_style))
    story.append(Paragraph(
        "<b>Support for H1 (Top-1 Accuracy = 100% under Controlled Coordination):</b> Under Condition C, PNI achieves <b>100% Top-1 accuracy</b> "
        "(20/20 seeds, Wilson 95% CI: [0.839, 1.000]) and an MRR of 1.000. The true coordinating pair achieves an average net score of <b>0.755 bits</b> "
        "[0.741, 0.769], decisively separated from competing non-coordinating pairs.",
        body_style
    ))
    story.append(Paragraph(
        "<b>Support for H2 (The 38-Fold Context Confounding Surge):</b> Under Condition B (independent agents reacting to shared context), naive Marginal MI "
        "explodes from 0.025 bits in Condition A to <b>0.958 bits</b> in Condition B—a <b>38-fold surge</b> in apparent action dependence—flagging 100% of "
        "non-coordinating pairs as colluders (FPR = 1.000 [1.000, 1.000], 120/120 pairs flagged). Unconditioned correlation is completely blind to shared context.",
        body_style
    ))
    story.append(Paragraph(
        "<b>Support for H3 (Disentangling State Conditioning from Competitor Subtraction):</b> Reporting Marginal MI, raw CMI, and PNI separately isolates the two pipeline mechanisms. "
        "Conditioning on state S_t drops raw dependence from 0.958 bits to <b>0.084 bits</b> [0.081, 0.087], falling below tau_CMI = 0.1175 bits to yield <b>0.000 FPR</b> (0/120 pairs). "
        "Competitor subtraction computes Gamma(i -&gt; j) = gamma(i, j) - max_k gamma(k, j); because all 4 agents experience symmetric residual dependence (~0.084 bits), "
        "the difference is small (0.012 bits [0.009, 0.015]), yielding PNI FPR <b>0.100</b> [0.050, 0.158] (12/120 pairs) under tau_PNI = 0.0104 bits. "
        "Importantly, PNI does not dominate CMI on all metrics: CMI achieves lower false-positive rates on non-coordinating pairs both in Condition B (0/120 vs. 12/120) and in Condition C (2/100 vs. 20/100), "
        "whereas PNI competitor subtraction is critical for directional ranking and isolating coordinating pairs from symmetric context.",
        body_style
    ))
    story.append(Paragraph(
        "<b>Support for H4 (Monotonic Scaling under Joint Gate):</b> In Condition D, varying joint coordination probability alpha via gate G_t ~ Bernoulli(alpha) "
        "produces strictly monotonic scaling of true-pair net influence: 0.264 bits (alpha=0.25), 0.469 bits (alpha=0.50), 0.623 bits (alpha=0.75), and 0.771 bits (alpha=1.00). "
        "PNI maintains 100% Top-1 accuracy across all tested alpha in [0.25, 1.00], whereas Marginal MI suffers 100% FPR across alpha &lt;= 0.50.",
        body_style
    ))

    # =========================================================================
    # PAGE 4: Sensitivity Sweep, Table 2, Figure 3, Trajectory Length Dynamics
    # =========================================================================
    story.append(PageBreak())

    story.append(Paragraph("5. Sensitivity Analysis: Trajectory Length (Scripted)", h1_style))
    story.append(Paragraph(
        "To evaluate finite-sample convergence, we executed a dedicated sweep across trajectory lengths T in {50, 100, 200, 500} rounds (Table 2). "
        "Evaluations used fixed primary calibrated thresholds (tau_MI = 0.030751, tau_CMI = 0.117454, tau_PNI = 0.010427 bits) across all lengths.",
        body_style
    ))

    headers2 = [
        "Length T", "Cond C PNI\nTop-1 (Wilson)", "Cond C PNI\nTrue Score (bits)", 
        "Cond B Marg MI\nScore (bits)", "Cond B CMI\nScore (bits)", "Cond B CMI\nFPR [Counts]", 
        "Cond B PNI\nNet Score (bits)", "Cond B PNI\nFPR [Counts]"
    ]
    data2 = [
        [Paragraph(h, table_header) for h in headers2],
        [
            Paragraph("<b>50 rounds</b>", table_cell), Paragraph("<b>1.00 [0.839, 1.000]</b>", table_cell),
            Paragraph("0.269 [0.250, 0.286]", table_cell), Paragraph("0.943 [0.884, 1.001]", table_cell),
            Paragraph("0.144 [0.134, 0.153]", table_cell), Paragraph("0.450 (54/120)", table_cell),
            Paragraph("0.0176 [0.0117, 0.0246]", table_cell), Paragraph("0.133 [0.083, 0.183]<br/>(16/120)", table_cell)
        ],
        [
            Paragraph("<b>100 rounds</b>", table_cell), Paragraph("<b>1.00 [0.839, 1.000]</b>", table_cell),
            Paragraph("0.499 [0.483, 0.515]", table_cell), Paragraph("0.964 [0.909, 1.021]", table_cell),
            Paragraph("0.112 [0.108, 0.118]", table_cell), Paragraph("0.042 (5/120)", table_cell),
            Paragraph("0.0131 [0.0084, 0.0181]", table_cell), Paragraph("0.108 [0.067, 0.158]<br/>(13/120)", table_cell)
        ],
        [
            Paragraph("<b>200 rounds</b>", table_cell), Paragraph("<b>1.00 [0.839, 1.000]</b>", table_cell),
            Paragraph("0.755 [0.741, 0.770]", table_cell), Paragraph("0.958 [0.932, 0.984]", table_cell),
            Paragraph("0.084 [0.081, 0.087]", table_cell), Paragraph("0.000* (0/120)", table_cell),
            Paragraph("0.0121 [0.0091, 0.0154]", table_cell), Paragraph("0.100 [0.050, 0.158]<br/>(12/120)", table_cell)
        ],
        [
            Paragraph("<b>500 rounds</b>", table_cell), Paragraph("<b>1.00 [0.839, 1.000]</b>", table_cell),
            Paragraph("1.052 [1.042, 1.062]", table_cell), Paragraph("0.958 [0.942, 0.973]", table_cell),
            Paragraph("<b>0.056 [0.054, 0.059]</b>", table_cell), Paragraph("<b>0.000* (0/120)</b>", table_cell),
            Paragraph("<b>0.0074 [0.0056, 0.0094]</b>", table_cell), Paragraph("<b>0.050 [0.017, 0.083]</b><br/>(6/120)", table_cell)
        ],
    ]
    t2 = Table(data2, colWidths=[0.75*inch, 0.98*inch, 0.95*inch, 0.90*inch, 0.85*inch, 0.80*inch, 0.95*inch, 0.90*inch])
    t2.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#0D47A1")),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#CCCCCC")),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8F9FA")]),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('PADDING', (0, 0), (-1, -1), 1.0),
    ]))
    story.append(t2)
    story.append(Paragraph("<b>Table 2: Trajectory Length Sensitivity (T in [50, 500]).</b> Evaluated across 20 independent seeds per cell under fixed primary calibrated thresholds. T=200 directly reuses primary benchmark trajectories. Underlying counts report flagged pairs / total negative pairs. *Denotes degenerate bootstrap intervals due to uniform zero flagged pairs across all seeds.", caption_style))
    story.append(Spacer(1, 1))

    fig3_path = FIGURES_DIR / "fig3_coordination_strength.png"
    fig5_path = FIGURES_DIR / "fig5_trajectory_length_sensitivity.png"
    if fig3_path.exists() and fig5_path.exists():
        t_figs2 = Table([
            [Image(str(fig3_path), width=3.45 * inch, height=1.45 * inch),
             Image(str(fig5_path), width=3.45 * inch, height=1.45 * inch)]
        ], colWidths=[3.55 * inch, 3.55 * inch])
        t_figs2.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('PADDING', (0, 0), (-1, -1), 0)]))
        story.append(t_figs2)
        story.append(Paragraph("<b>Figure 3: Detection Boundaries and Sample Scaling.</b> Left: Top-1 Accuracy across coordination strength alpha. Right: Finite-sample behavior of spurious correlation vs. raw CMI vs. conditioned PNI net influence across trajectory length T in [50, 500].", caption_style))
    story.append(Spacer(1, 1))

    story.append(Paragraph(
        "<b>Trajectory Length Dynamics:</b> Over the tested T = 50–500 range, unconditioned Marginal MI in Condition B remains stubbornly elevated (~0.94–0.96 bits). "
        "In contrast, the estimated raw CMI score declines monotonically from 0.144 bits at T = 50 down to 0.056 bits at T = 500 (a 61% reduction), bringing CMI FPR from 0.450 to 0.000. "
        "Similarly, the PNI net score declines from 0.0176 bits at T = 50 down to 0.0074 bits at T = 500 (a 58% reduction), reducing Condition B PNI false positives from 0.133 to 0.050. "
        "PNI achieves 100% Top-1 accuracy across all tested lengths in Condition C.",
        body_style
    ))

    # =========================================================================
    # PAGE 5: Open-Weight LLM Agent Experiments (Modal CPU), Table 3, Figure 6
    # =========================================================================
    story.append(PageBreak())

    story.append(Paragraph("6. Open-Weight LLM Agent Experiments (Modal CPU)", h1_style))
    story.append(Paragraph(
        "To investigate whether information-theoretic collusion detectors generalize to modern generative foundation models, we deployed open-weight "
        "<b>Qwen/Qwen2.5-1.5B-Instruct</b> across three parallel horizons (T in {5, 20, 50} rounds) on Modal cloud CPU infrastructure (4 vCPUs, 8 GB RAM per worker). "
        "Four simulated agent roles were queried through the same model checkpoint with separate prompts and per-decision sampling seeds to preserve independent stochasticity: "
        "(1) <b>LLM-A</b> (independent action selection, individual payoff maximization); (2) <b>LLM-B</b> (shared public plurality state counter-strategy); and "
        "(3) <b>LLM-C</b> (controlled positive control: private random signal Z_t delivered to pair (0, 1) and strictly excluded from detector logs). "
        "Public state was abstracted to 5 states: S in {START, ROCK, PAPER, SCISSORS, TIE}. A bounded JSON parser ensured 100% of decisions produced a valid parsed action (ROCK, PAPER, SCISSORS). "
        "Timing reports distinguish batch wall-clock duration from per-decision inference latency, with authoritative costs cited from Modal billing telemetry.",
        body_style
    ))

    headers3 = [
        "Horizon", "Condition", "Traj.", "Decisions", "Valid Rate", "Latency",
        "Signal Compl.", "Top-1 Marg. MI", "Top-1 CMI", "Top-1 PNI",
        "Mean Marg. MI", "Mean CMI", "Mean PNI Net"
    ]
    data3 = [
        [Paragraph(h, table_header) for h in headers3],
        # T=5
        [
            Paragraph("<b>T = 5</b>", table_cell), Paragraph("LLM-A (Ind.)", table_cell), Paragraph("40", table_cell),
            Paragraph("800", table_cell), Paragraph("1.000 (800/800)", table_cell), Paragraph("4.06s", table_cell),
            Paragraph("—", table_cell), Paragraph("—", table_cell), Paragraph("—", table_cell), Paragraph("—", table_cell),
            Paragraph("0.1912", table_cell), Paragraph("0.0693", table_cell), Paragraph("-0.0113", table_cell)
        ],
        [
            Paragraph("<b>T = 5</b>", table_cell), Paragraph("LLM-B (Cont.)", table_cell), Paragraph("40", table_cell),
            Paragraph("800", table_cell), Paragraph("1.000 (800/800)", table_cell), Paragraph("8.65s", table_cell),
            Paragraph("—", table_cell), Paragraph("—", table_cell), Paragraph("—", table_cell), Paragraph("—", table_cell),
            Paragraph("0.1283", table_cell), Paragraph("0.0666", table_cell), Paragraph("-0.0184", table_cell)
        ],
        [
            Paragraph("<b>T = 5</b>", table_cell), Paragraph("<b>LLM-C (Coord.)</b>", table_cell), Paragraph("40", table_cell),
            Paragraph("800", table_cell), Paragraph("1.000 (800/800)", table_cell), Paragraph("4.84s", table_cell),
            Paragraph("<b>1.000 (400/400)</b>", table_cell), Paragraph("<b>1.000 (40/40)</b>", table_cell),
            Paragraph("<b>0.700 (28/40)</b>", table_cell), Paragraph("<b>0.700 (28/40)</b>", table_cell),
            Paragraph("0.1623", table_cell), Paragraph("0.0696", table_cell), Paragraph("-0.0182", table_cell)
        ],
        # T=20
        [
            Paragraph("<b>T = 20</b>", table_cell), Paragraph("LLM-A (Ind.)", table_cell), Paragraph("100", table_cell),
            Paragraph("8000", table_cell), Paragraph("1.000 (8000/8000)", table_cell), Paragraph("4.99s", table_cell),
            Paragraph("—", table_cell), Paragraph("—", table_cell), Paragraph("—", table_cell), Paragraph("—", table_cell),
            Paragraph("0.3100", table_cell), Paragraph("0.0997", table_cell), Paragraph("-0.0310", table_cell)
        ],
        [
            Paragraph("<b>T = 20</b>", table_cell), Paragraph("LLM-B (Cont.)", table_cell), Paragraph("100", table_cell),
            Paragraph("8000", table_cell), Paragraph("1.000 (8000/8000)", table_cell), Paragraph("8.65s", table_cell),
            Paragraph("—", table_cell), Paragraph("—", table_cell), Paragraph("—", table_cell), Paragraph("—", table_cell),
            Paragraph("0.1239", table_cell), Paragraph("0.0981", table_cell), Paragraph("-0.0383", table_cell)
        ],
        [
            Paragraph("<b>T = 20</b>", table_cell), Paragraph("<b>LLM-C (Coord.)</b>", table_cell), Paragraph("100", table_cell),
            Paragraph("8000", table_cell), Paragraph("1.000 (8000/8000)", table_cell), Paragraph("7.27s", table_cell),
            Paragraph("<b>1.000 (4000/4000)</b>", table_cell), Paragraph("<b>1.000 (100/100)</b>", table_cell),
            Paragraph("<b>1.000 (100/100)</b>", table_cell), Paragraph("<b>1.000 (100/100)</b>", table_cell),
            Paragraph("0.2403", table_cell), Paragraph("0.1333", table_cell), Paragraph("-0.1400", table_cell)
        ],
        # T=50
        [
            Paragraph("<b>T = 50</b>", table_cell), Paragraph("LLM-A (Ind.)", table_cell), Paragraph("70", table_cell),
            Paragraph("14000", table_cell), Paragraph("1.000 (14000/14000)", table_cell), Paragraph("4.60s", table_cell),
            Paragraph("—", table_cell), Paragraph("—", table_cell), Paragraph("—", table_cell), Paragraph("—", table_cell),
            Paragraph("0.4050", table_cell), Paragraph("0.0835", table_cell), Paragraph("-0.0238", table_cell)
        ],
        [
            Paragraph("<b>T = 50</b>", table_cell), Paragraph("LLM-B (Cont.)", table_cell), Paragraph("70", table_cell),
            Paragraph("14000", table_cell), Paragraph("1.000 (14000/14000)", table_cell), Paragraph("8.13s", table_cell),
            Paragraph("—", table_cell), Paragraph("—", table_cell), Paragraph("—", table_cell), Paragraph("—", table_cell),
            Paragraph("0.0833", table_cell), Paragraph("0.0833", table_cell), Paragraph("-0.0341", table_cell)
        ],
        [
            Paragraph("<b>T = 50</b>", table_cell), Paragraph("<b>LLM-C (Coord.)</b>", table_cell), Paragraph("70", table_cell),
            Paragraph("14000", table_cell), Paragraph("1.000 (14000/14000)", table_cell), Paragraph("7.52s", table_cell),
            Paragraph("<b>1.000 (7000/7000)</b>", table_cell), Paragraph("<b>1.000 (70/70)</b>", table_cell),
            Paragraph("<b>1.000 (70/70)</b>", table_cell), Paragraph("<b>1.000 (70/70)</b>", table_cell),
            Paragraph("0.2614", table_cell), Paragraph("0.1770", table_cell), Paragraph("-0.3206", table_cell)
        ],
    ]
    t3 = Table(data3, colWidths=[0.45*inch, 0.95*inch, 0.30*inch, 0.45*inch, 0.70*inch, 0.40*inch, 0.75*inch, 0.60*inch, 0.55*inch, 0.55*inch, 0.50*inch, 0.45*inch, 0.45*inch])
    t3.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#0D47A1")),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#CCCCCC")),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8F9FA")]),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('PADDING', (0, 0), (-1, -1), 0.7),
    ]))
    story.append(t3)
    story.append(Paragraph("<b>Table 3: Multi-Horizon LLM Empirical Results (Qwen2.5-1.5B, 630 trajectories, 68,400 total decisions).</b> Evaluated across three horizons: Pilot (T=5, 40 seeds, 2,400 decisions), Expanded Primary (T=20, 100 seeds, 24,000 decisions), and Extended Horizon (T=50, 70 seeds, 42,000 decisions). Evaluated via pair rankings, empirical mutual information, and held-out calibrated thresholds (Table 4).", caption_style))
    story.append(Spacer(1, 1))

    fig6_path = FIGURES_DIR / "fig6_llm_horizon_scaling.png"
    if fig6_path.exists():
        story.append(Image(str(fig6_path), width=7.0 * inch, height=1.60 * inch))
        story.append(Paragraph("<b>Figure 4: LLM Multi-Horizon Scaling and Empirical Signal Separation.</b> Left: Top-1 ranking accuracy of coordinating pair (0, 1) in Condition LLM-C across horizons T in {5, 20, 50}. Ultra-short horizons (T=5) suffer sample sparsity over |S|=5 states (70.0% Top-1 accuracy), whereas T >= 20 restores 100% accuracy (100/100 seeds at T=20, 70/70 seeds at T=50). Right: Empirical CMI separation between coordinated and baseline conditions as sample horizon deepens.", caption_style))
    story.append(Spacer(1, 1))

    story.append(Paragraph(
        "<b>Key Empirical Discoveries in LLM Auditing:</b><br/>"
        "1. <i>Instruction Compliance in Simplified Games:</i> Open-weight Qwen2.5-1.5B-Instruct achieved 100.0% valid action selection (100% of decisions produced a valid parsed action) "
        "without falling back or producing unparseable text. In Condition LLM-C, coordinating agents achieved <b>100.0% adherence</b> "
        "to the secret coordination directive across all tested seeds (11,400/11,400 opportunities across horizons), demonstrating high instruction compliance and a controlled statistical dependence pattern in simplified RPS rather than spontaneous collusion or an economic cartel.<br/>"
        "2. <i>Empirical Finite-Sample Horizon Sparsity Effect:</i> At T=5 rounds, state conditioning over 5 states fragments the empirical sample into sparse bins (E[N_s] ~ 1), "
        "reducing CMI and PNI Top-1 accuracy to 70.0% (28/40 seeds) and binary recall to 36.7% (with 33.3% of episodes ranked #1 but NOT threshold-detected). However, expanding the horizon to T &gt;= 20 rounds provides sufficient history to overcome sample sparsity: "
        "Top-1 ranking accuracy and binary threshold recall identify the designated shared-signal pair with <b>100.0% accuracy</b> (100/100 seeds at T=20, 70/70 seeds at T=50) under controlled ranking evidence.<br/>"
        "3. <i>Negative PNI Net Scores and Ranking vs. Threshold Detection:</i> In Condition LLM-C, non-coordinating candidate pairs frequently yield negative PNI net scores "
        "because competitor subtraction (max_{k != i,j} gamma(k,j)) subtracts the elevated mutual information of the coordinating pair (0, 1), driving rival net influence negative (mean -0.140 bits at T=20, -0.321 bits at T=50). "
        "Furthermore, under finite sample sizes or high background noise, subtracting the strongest rival can yield negative values even for the true pair. "
        "Consequently, relative ranking must not be conflated with absolute threshold-based classification.<br/>"
        "4. <i>Cloud Resource and Authoritative Financial Accounting:</i> The LLM experimental pipeline was executed across parallel containers on Modal cloud CPU infrastructure (4 vCPU, 8 GB RAM per worker). "
        "Authoritative financial accounting from Modal billing telemetry confirms all metered compute was fully offset by promotional credits and the network egress allowance, resulting in strictly <b>$0.00 billed out-of-pocket spend</b> ($40.63 metered compute: $40.12 promotional credit applied, $0.51 egress allowance).",
        body_style
    ))

    # =========================================================================
    # PAGE 6: Table 4, Discussion and Limitations, Conclusion
    # =========================================================================
    story.append(PageBreak())

    story.append(Paragraph("6.3 Held-Out Classification and Threshold Evaluation", h2_style))
    story.append(Paragraph(
        "To rigorously separate relative ranking from absolute detection under finite samples, we calibrated decision thresholds on LLM-A calibration seeds "
        "at nominal 5% FPR (tau_MI = 0.3610/0.5689/0.6961, tau_CMI = 0.1025/0.1696/0.1627, tau_PNI = 0.0154/0.0570/0.0621 bits for T in {5, 20, 50}). "
        "Table 4 reports held-out classification metrics across independent (LLM-A), confounded (LLM-B), and coordinated (LLM-C) test trajectories.",
        body_style
    ))

    # Table 4: LLM Threshold Calibration and Held-Out Classification Metrics
    headers4 = ["Horizon", "Detector", "Cal. Thresh", "LLM-A FPR", "LLM-B FPR", "LLM-C Top-1", "LLM-C Recall", "Ranked #1 & Det.", "Ranked #1 Not Det."]
    data4 = [
        [Paragraph(h, table_header) for h in headers4],
        # T=5
        [
            Paragraph("<b>T = 5</b>", table_cell), Paragraph("Marginal MI", table_cell), Paragraph("0.3610", table_cell),
            Paragraph("0.267 (8/30)", table_cell), Paragraph("0.067 (2/30)", table_cell), Paragraph("1.000 [0.886, 1.000]", table_cell),
            Paragraph("0.300", table_cell), Paragraph("0.300", table_cell), Paragraph("0.700", table_cell)
        ],
        [
            Paragraph("<b>T = 5</b>", table_cell), Paragraph("CMI", table_cell), Paragraph("0.1025", table_cell),
            Paragraph("0.200 (6/30)", table_cell), Paragraph("0.300 (9/30)", table_cell), Paragraph("0.700 [0.521, 0.833]", table_cell),
            Paragraph("0.333", table_cell), Paragraph("0.267", table_cell), Paragraph("0.433", table_cell)
        ],
        [
            Paragraph("<b>T = 5</b>", table_cell), Paragraph("PNI Net Score", table_cell), Paragraph("0.0154", table_cell),
            Paragraph("0.467 (14/30)", table_cell), Paragraph("0.333 (10/30)", table_cell), Paragraph("0.700 [0.521, 0.833]", table_cell),
            Paragraph("0.367", table_cell), Paragraph("0.367", table_cell), Paragraph("0.333", table_cell)
        ],
        # T=20
        [
            Paragraph("<b>T = 20</b>", table_cell), Paragraph("Marginal MI", table_cell), Paragraph("0.5689", table_cell),
            Paragraph("0.213 (16/75)", table_cell), Paragraph("0.000 (0/75)", table_cell), Paragraph("1.000 [0.951, 1.000]", table_cell),
            Paragraph("1.000", table_cell), Paragraph("1.000", table_cell), Paragraph("0.000", table_cell)
        ],
        [
            Paragraph("<b>T = 20</b>", table_cell), Paragraph("CMI", table_cell), Paragraph("0.1696", table_cell),
            Paragraph("0.147 (11/75)", table_cell), Paragraph("0.240 (18/75)", table_cell), Paragraph("1.000 [0.951, 1.000]", table_cell),
            Paragraph("1.000", table_cell), Paragraph("1.000", table_cell), Paragraph("0.000", table_cell)
        ],
        [
            Paragraph("<b>T = 20</b>", table_cell), Paragraph("PNI Net Score", table_cell), Paragraph("0.0570", table_cell),
            Paragraph("0.147 (11/75)", table_cell), Paragraph("0.173 (13/75)", table_cell), Paragraph("1.000 [0.951, 1.000]", table_cell),
            Paragraph("1.000", table_cell), Paragraph("1.000", table_cell), Paragraph("0.000", table_cell)
        ],
        # T=50
        [
            Paragraph("<b>T = 50</b>", table_cell), Paragraph("Marginal MI", table_cell), Paragraph("0.6961", table_cell),
            Paragraph("0.033 (2/60)", table_cell), Paragraph("0.000 (0/60)", table_cell), Paragraph("1.000 [0.940, 1.000]", table_cell),
            Paragraph("1.000", table_cell), Paragraph("1.000", table_cell), Paragraph("0.000", table_cell)
        ],
        [
            Paragraph("<b>T = 50</b>", table_cell), Paragraph("CMI", table_cell), Paragraph("0.1627", table_cell),
            Paragraph("0.050 (3/60)", table_cell), Paragraph("0.117 (7/60)", table_cell), Paragraph("1.000 [0.940, 1.000]", table_cell),
            Paragraph("1.000", table_cell), Paragraph("1.000", table_cell), Paragraph("0.000", table_cell)
        ],
        [
            Paragraph("<b>T = 50</b>", table_cell), Paragraph("PNI Net Score", table_cell), Paragraph("0.0621", table_cell),
            Paragraph("0.067 (4/60)", table_cell), Paragraph("0.117 (7/60)", table_cell), Paragraph("1.000 [0.940, 1.000]", table_cell),
            Paragraph("1.000", table_cell), Paragraph("1.000", table_cell), Paragraph("0.000", table_cell)
        ],
    ]
    t4 = Table(data4, colWidths=[0.45*inch, 0.75*inch, 0.60*inch, 0.85*inch, 0.85*inch, 0.85*inch, 0.70*inch, 0.95*inch, 1.05*inch])
    t4.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#0D47A1")),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#CCCCCC")),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8F9FA")]),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('PADDING', (0, 0), (-1, -1), 0.6),
    ]))
    story.append(t4)
    story.append(Paragraph("<b>Table 4: LLM Threshold Calibration and Held-Out Classification Metrics.</b> Calibrated on LLM-A calibration seeds at nominal 5% FPR. Evaluated on held-out test seeds across conditions (T=5: 30 seeds; T=20: 75 seeds; T=50: 60 seeds). Reports episode FPR on independent (LLM-A) and confounded (LLM-B) controls, and true-pair recall, Top-1 accuracy, and diagnostic separation between 'Ranked #1 & Detected' vs 'Ranked #1 but NOT Detected' in Condition LLM-C.", caption_style))
    story.append(Spacer(1, 1))

    story.append(Paragraph("7. Discussion and Limitations", h1_style))
    story.append(Paragraph(
        "<b>7.1 Auditing Implications: Why Correlation Lies:</b> In algorithmic markets, autonomous pricing agents, high-frequency execution bots, "
        "and procurement models continuously observe common economic shocks (e.g., benchmark interest rates, commodity prices, wholesale tariffs). "
        "In this controlled environment, our empirical results illustrate that unconditioned correlation metrics (e.g., Pearson correlation, raw mutual information) cannot differentiate "
        "rational adaptation from collusive coordination. Auditing architectures relying on unconditioned metrics face a substantial risk of Type I errors, "
        "potentially targeting competitive firms solely because they adapted efficiently to common public information. State conditioning provides an essential statistical safeguard to reduce this confounding risk.",
        body_style
    ))
    story.append(Paragraph(
        "<b>7.2 Limitations:</b> We transparently acknowledge the constraints of this study:<br/>"
        "1. <i>Controlled Scripted Signatures vs. Real-World Cartels:</i> Condition C establishes a controlled <i>shared-private-signal coordination condition</i> "
        "demonstrating that PNI recognizes statistical action dependence in scripted matrix games. However, detecting this statistical signature does not prove "
        "that agents formed an economically harmful cartel, extracted supra-competitive rents, or inflicted market harm. Furthermore, unobserved common causes "
        "(e.g., unobserved common private inputs, shared proprietary features, or unmodeled system states) could generate similar conditional action dependence.<br/>"
        "2. <i>Estimator Regularization Sensitivity:</i> In our 4-player game with |S| = 82 states, state conditioning partitions observations across sparse cells. "
        "Evaluating smoothing sensitivity under Condition B at T = 200 reveals that the unsmoothed plug-in estimator (using 0 log 0 = 0) yields CMI = 0.062 bits, "
        "while Dirichlet smoothing yields 0.084 bits (Jeffreys, lambda = 0.5) and 0.096 bits (Laplace, lambda = 1.0). Pseudocount smoothing introduces a mild upward baseline "
        "in sparse regimes, though all values remain well below unconditioned Marginal MI (0.958 bits).<br/>"
        "3. <i>Exploratory Small-Sample Calibration:</i> Nominal 5% decision thresholds were calibrated from 5 validation seeds (30 candidate pairs) of Condition A. "
        "While isolating calibration from the 15 held-out test seeds, 30 samples yield coarse quantile estimates and do not guarantee an exact 5% population FPR.<br/>"
        "4. <i>Modal Promotional Compute Telemetry & Cloud Boundaries:</i> An extensive 68,400-decision study using Qwen2.5-1.5B-Instruct was executed on Modal CPU instances (4 cores, 8GB RAM). "
        "Allocating cloud GPU instances (T4/L4) required an active payment method on file under Modal platform policy, which was safely avoided under our zero-out-of-pocket spending cap ($0.00). "
        "The CPU pipeline logged $40.63 in metered compute ($40.12 promotional credits applied for ephemeral apps, $0.51 network egress allowance; $0.00 billed out of pocket) across 630 trajectories (68,400 decisions). While establishing that 1.5B instruction models achieve 100% signal compliance "
        "and that T >= 20 restores 100% ranking accuracy and threshold recall, canonical benchmark results remain grounded in the 260-trajectory scripted evaluation (54,000 rounds).",
        body_style
    ))
    story.append(Paragraph(
        "<b>7.3 Future Work:</b> Key extensions include: (1) evaluating neural CMI estimators (e.g., MINE) on LLM auction transcripts (Agrawal et al., 2025); "
        "(2) developing dynamic state abstractions to compress high-dimensional order book histories; and (3) testing PNI under intentional adversarial evasion.",
        body_style
    ))
    story.append(Spacer(1, 2))

    story.append(Paragraph("8. Conclusion", h1_style))
    story.append(Paragraph(
        "This research stress-tested Pairwise Net Influence for detecting multi-agent coordination. "
        "In this controlled shared-context condition, independent agents reacting to the same observable state produced a 38-fold increase in estimated marginal mutual information and a 100% false-positive rate under the evaluated threshold. "
        "Conditioning on observable state neutralizes this broadcast shock. Under genuine scripted coordination, PNI ranked the designated coordinating pair first in all 20 scripted positive-control trajectories. "
        "However, at the calibrated decision threshold it flagged 20/100 non-target pairs in this condition, compared with 2/100 for CMI, illustrating that pair ranking and threshold-based false-positive control are distinct outcomes. "
        "Furthermore, across open-weight language model decisions, state-conditioned detectors achieve 100% identification accuracy once trajectory length reaches T &gt;= 20 rounds, overcoming finite-sample state sparsity in controlled settings. "
        "These results support state conditioning as a useful safeguard in the tested setting; its performance in richer environments and under adversarial or unobserved confounding requires further evaluation.",
        body_style
    ))

    # =========================================================================
    # PAGE 7: Code & Data, Contributions, References, Mandatory Appendix
    # =========================================================================
    story.append(PageBreak())

    story.append(Paragraph("Code and Data", h1_style))
    story.append(Paragraph(
        "• <b>Code Repository:</b> All experimental scripts, detectors, environments, test suites, and report generation tools are packaged in "
        "<font face='Courier'>when_correlation_lies_all_source_code.txt</font> with SHA-256 checksums.<br/>"
        "• <b>Data & Trajectories:</b> Full scripted JSONL trajectories (260 unique files, 54,000 rounds) and complete LLM trajectories across all three horizons (630 unique files, 68,400 decisions) "
        "with separate ground-truth manifests are included in the review bundle ZIP (<font face='Courier'>data/raw/</font>, <font face='Courier'>data/eval_labels/</font>, "
        "<font face='Courier'>data/raw_llm/</font>, <font face='Courier'>data/eval_labels_llm/</font>, <font face='Courier'>data/raw_llm_expanded/</font>, "
        "<font face='Courier'>data/eval_labels_llm_expanded/</font>, <font face='Courier'>data/raw_llm_expanded_t50/</font>, <font face='Courier'>data/eval_labels_llm_expanded_t50/</font>).<br/>"
        "• <b>Reproducibility:</b> Complete automated test suite passes (59/59 unit tests) in Python 3.13 on standard CPU hardware.",
        body_style
    ))
    story.append(Spacer(1, 1))

    story.append(Paragraph("Author Contributions", h1_style))
    story.append(Paragraph(
        "<b>Durgesh Unde (Independent Researcher):</b> Project conceptualization, selection and formulation of research questions and experimental conditions, "
        "project direction, review of experimental outputs, qualitative interpretation of detection metrics, and final editorial responsibility for the manuscript.",
        body_style
    ))
    story.append(Spacer(1, 1))

    story.append(Paragraph("References", h1_style))
    refs = [
        "Agrawal, K., Teo, V., Vazquez, J. J., Kunnavakkam, S., Srikanth, V., & Liu, A. (2025). Evaluating LLM Agent Collusion in Double Auctions. <i>arXiv preprint arXiv:2507.01413</i>.",
        "Bonjour, T., Aggarwal, V., & Bhargava, B. (2022). Information-theoretic approach to detect collusion in multi-agent games. <i>Proceedings of Machine Learning Research (UAI 2022)</i>, 180, 223–232.",
        "Calvano, E., Calzolari, G., Denicolò, V., & Pastorello, S. (2020). Artificial intelligence, algorithmic pricing, and collusion. <i>American Economic Review</i>, 110(10), 3267–3297.",
        "Cover, T. M., & Thomas, J. A. (2006). <i>Elements of Information Theory</i> (2nd ed.). John Wiley & Sons.",
        "Holste, D., Grosse, I., & Herzel, H. (1998). Bayes' estimators of generalized entropies. <i>Journal of Physics A: Mathematical and General</i>, 31(11), 2551–2566.",
        "Paninski, L. (2003). Estimation of entropy and mutual information. <i>Neural Computation</i>, 15(6), 1191–1253.",
        "Schwalbe, U. (2018). Algorithms, machine learning, and collusion. <i>Journal of Competition Law & Economics</i>, 14(4), 568–607.",
    ]
    for r in refs:
        story.append(Paragraph(f"• {r}", bullet_style))
    story.append(Spacer(1, 1))

    story.append(Paragraph("Appendix: Limitations and Dual-Use / Ethical Considerations", h1_style))
    story.append(Paragraph(
        "<b>Mandatory Ethical & Dual-Use Analysis:</b> Auditing multi-agent systems for collusion possesses significant dual-use implications:<br/>"
        "1. <i>Defensive Regulatory Oversight:</i> Information-theoretic detectors empower market regulators, exchange operators, and platform architects "
        "to continuously monitor high-frequency trading and procurement markets for tacit cartels without requiring invasive access to proprietary model weights.<br/>"
        "2. <i>Adversarial Exploitation & Stealth Evasion:</i> Conversely, adversarial agent developers could incorporate PNI as an explicit penalty term "
        "in multi-agent reinforcement learning objectives. By penalizing conditional mutual information, malicious actors could train stealthy collusive policies "
        "that sustain supracompetitive markups while remaining statistically undetectable under state-conditioned audits.<br/>"
        "3. <i>Harms of False Accusations:</i> Our Condition B results demonstrate the catastrophic risk of unconditioned metrics: a 100% false accusation rate "
        "against competitive agents responding to shared context. Auditing architectures must mandate state conditioning and calibrated uncertainty intervals "
        "before initiating punitive regulatory actions.",
        body_style
    ))
    story.append(Spacer(1, 1))

    story.append(Paragraph("LLM Usage Statement", h1_style))
    story.append(Paragraph(
        "ChatGPT (OpenAI) assisted with research ideation, paper explanation, methodology critique, independent review, "
        "and prompt drafting. Antigravity (Google DeepMind advanced agentic coding assistant) assisted with code implementation, "
        "unit test suites, experiment orchestration, Modal CPU cloud infrastructure harness and execution, statistical metric aggregations, visualizations, ReportLab PDF layout, "
        "and packaging under the author's iterative instructions and review. Project direction, experimental design choices, "
        "qualitative analysis, and final editorial responsibility rest entirely with the author (Durgesh Unde). Canonical benchmark evaluations used 260 scripted trajectories (54,000 rounds); open-weight LLM evaluations used 630 trajectories (68,400 decisions) executed on Modal CPU ($40.63 metered compute: $40.12 promotional credits applied, $0.51 network egress allowance; $0.00 out-of-pocket spend). Zero personal payment cards or external paid token APIs were used. The experimental protocol was frozen after exploratory prototyping and was not preregistered prior to exploration.",
        body_style
    ))
    story.append(Spacer(1, 1))
    story.append(Paragraph("________________<br/><sup>1</sup> Research conducted for the Apart Research AI Collusion Research Sprint, October 23–25, 2026.", caption_style))

    doc.build(story, canvasmaker=NumberedCanvas)
    print(f"Report successfully compiled to: {PDF_PATH}")
    return PDF_PATH


if __name__ == "__main__":
    build_pdf()
